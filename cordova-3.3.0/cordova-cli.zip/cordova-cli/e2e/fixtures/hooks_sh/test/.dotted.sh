echo "Dotted files in hook dirs should not be called" > dotted_hook_should_not_fire.txt
