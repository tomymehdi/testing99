echo "this is script 0 in `pwd`";
echo b >> hooks_order.txt
