Cordova/Ubuntu
==========

Cordova/Ubuntu is the Ubuntu port of the Apache Cordova project.

Requirements
------------

- Ubuntu SDK

License
-------

Licensed under the APACHE-2.0 license. See LICENSE file for details.
