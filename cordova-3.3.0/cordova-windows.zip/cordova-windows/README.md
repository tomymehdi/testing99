# Apache Cordova for Windows
===

This repo may eventually hold, Windows8, Windows7, Win32, win.net, or other windows desktop related implementations of the Apache Cordova API.

